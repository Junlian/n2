----

This is a source file for C language

----


main()

{

}

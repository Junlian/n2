-----


This is fileJava.java

-----


package hq1;

public class hq1{


public static void main(String[] args){
	system.out.println("hello world");

}
}

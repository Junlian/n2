----


This is source file for c plus plus language

----


cout<<"hello world"<<endl;
